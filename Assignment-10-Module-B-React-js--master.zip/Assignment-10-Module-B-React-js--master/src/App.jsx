import React from 'react'
import { RouterApp } from './Config/RouterApp';
import './App.css'

const App = () => {
  return (
   <RouterApp/>
  )
}

export default App;