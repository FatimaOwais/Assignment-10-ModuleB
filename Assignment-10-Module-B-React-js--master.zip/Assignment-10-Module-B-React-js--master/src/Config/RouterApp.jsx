import React from 'react'
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom'
import { Product } from '../Pages/Product'
import { Product_Details } from '../Pages/Details'


const router = createBrowserRouter(createRoutesFromElements(
<Route>
    <Route path='' element={<Product/>}/>

    {/* Dynamic Routes */}
    <Route path='/product/:id' element={<Product_Details/>}/>
</Route>

))

export const RouterApp = () => {
  return (
    <RouterProvider router={router}/>
  )
}

